clear; clc; close;
%below we ask the user for all the parameters needed before we proceed
fprintf('Please choose the pulse shape:\n');
fprintf('1. NRZ\n2. Ideal Nyquist Pulse\n3. Raised-Cosine\n4. Square Root Raised-Cosine\n');
pulse_type = input('Enter the number of the chosen type: ');
pam_level = input('Enter numebr of PAM levels(2 or 8): ');
duration = input('Enter 1 for eye digram of duration Ts or 2 for duration 2Ts: ');

%generate 300 random bits uniformly distributed(equiprobable bits)
no_bits = 300; %number of bits to generate
bits = randi([0, 1], 1, no_bits);
Tb = 1; %each pulse is 1 sec
fs = 1000; %sampling freq used to plot pulses

switch pulse_type %decide which pulse type to use based on the user's choice
    case 1 %polar
        encoded = PolarPAM(bits, pam_level);
        %repeat each value in the encoded array Ts*fs times to make it a pulse
        encoded_pulses = repelem(encoded, Tb*fs);
        %define the time axis for the desired time(either Ts or 2Ts)
        t = linspace(0, duration*Tb, duration*Tb*fs);
        %draw eye diagram by taking one/two pulse each iteration and imposing it on the plot
        for i = 1 : duration*Tb*fs : length(encoded_pulses)
            encoded_pulses(1, i) = 0;
            encoded_pulses(1, i + duration*Tb*fs - 1) = 0;
            plot(t, encoded_pulses(1, i : i + duration*Tb*fs - 1))
            hold on
        end
        grid on; xlim([-0.1 duration*Tb + 0.1]);
        title(sprintf('Eye Diagram of %d level Polar PAM with duaration %dTs', pam_level, duration))
        xlabel('time s')
        ylabel('Amplitude V')
    case 2 %Ideal nyquist
        %define the time axis on which we want to generate the sinc signal
        t_sinc = linspace(-5, 5, Tb*1001*10);
        %generate the sinc signal using the time axis defined above
        raised_cos = sinc(t_sinc);
        %apply polar pam to the input bits to transform the input into correct levels
        input = PolarPAM(bits, pam_level);
        %repeat each value in the encoded array Tb*1001 times to make it a pulse of same width as sinc
        input_pulses = repelem(input, Tb*1001);
        %we want to turn the pulses into just an impulse in the middle of the pulse
        %generate array of zeros same length as the input_pulses
        temp = zeros(1, length(input_pulses));
        %only put 1 in the middle of each pulse
        temp(501:1001:end) = 1;
        %finally to get the impulses multiply element by element in temp and input_pulses
        impulses = temp.*input_pulses;
        %convolve sinc signal and input impulses together to obtain pam modulation
        result = conv(raised_cos, impulses, 'same');
        t = linspace(0, duration*Tb, duration*Tb*1001);
        %draw eye diagram by taking one/two pulse each iteration and imposing it on the plot
        for i = 1 : duration*Tb*1001 : length(result)
            plot(t, result(1, i : i + duration*Tb*1001 - 1))
            hold on
        end
        grid on; xlim([-0.1 duration*Tb + 0.1]);
        title(sprintf('Eye Diagram of %d level Ideal Nyquist PAM with duaration %dTs', pam_level, duration))
        xlabel('time s')
        ylabel('Amplitude V')
    case 3 %raised cos
        %define the time axis on which we want to generate the sinc signal
        t_sinc = linspace(-5, 5, Tb*1001*10);
        %define the roll off factor
        alpha = 1;
        %generate the raised cos signal using the time axis defined above
        raised_cos = sinc(t_sinc).*cos(2*pi*alpha*t_sinc)./(1-16*(alpha^2)*(t_sinc.^2));
        %apply polar pam to the input bits to transform the input into correct levels
        input = PolarPAM(bits, pam_level);
        %repeat each value in the encoded array Tb*1001 times to make it a pulse of same width as sinc
        input_pulses = repelem(input, Tb*1001);
        %we want to turn the pulses into just an impulse in the middle of the pulse
        %generate array of zeros same length as the input_pulses
        temp = zeros(1, length(input_pulses));
        %only put 1 in the middle of each pulse
        temp(501:1001:end) = 1;
        %finally to get the impulses multiply element by element in temp and input_pulses
        impulses = temp.*input_pulses;
        %convolve sinc signal and input impulses together to obtain pam modulation
        result = conv(raised_cos, impulses, 'same');
        t = linspace(0, duration*Tb, duration*Tb*1001);
        %draw eye diagram by taking one/two pulse each iteration and imposing it on the plot
        for i = 1 : duration*Tb*1001 : length(result)
            plot(t, result(1, i : i + duration*Tb*1001 - 1))
            hold on
        end
        grid on; xlim([-0.1 duration*Tb + 0.1]);
        title(sprintf('Eye Diagram of %d level Raised Cos PAM with duaration %dTs', pam_level, duration))
        xlabel('time s')
        ylabel('Amplitude V')
    case 4 %sqrt raised cos
        %define the time axis on which we want to generate the sinc signal
        t_sinc = linspace(-5, 5, Tb*1001*10);
        %define the roll off factor
        alpha = 1; Tc = 0.2604167;
        %generate the raised cos signal using the time axis defined above
        num = cos(pi*t_sinc*(1+alpha)/Tc) + (Tc./(4*alpha*t_sinc)).*sin(pi*t_sinc*(1-alpha)/Tc);
        den = 1 - (4*alpha*t_sinc/Tc).^2;
        sqrt_raised_cos = (4*alpha/(pi*sqrt(Tc)))*num./den;
        %apply polar pam to the input bits to transform the input into correct levels
        input = PolarPAM(bits, pam_level);
        %repeat each value in the encoded array Tb*1001 times to make it a pulse of same width as sinc
        input_pulses = repelem(input, Tb*1001);
        %we want to turn the pulses into just an impulse in the middle of the pulse
        %generate array of zeros same length as the input_pulses
        temp = zeros(1, length(input_pulses));
        %only put 1 in the middle of each pulse
        temp(501:1001:end) = 1;
        %finally to get the impulses multiply element by element in temp and input_pulses
        impulses = temp.*input_pulses;
        %convolve sinc signal and input impulses together to obtain pam modulation
        result = conv(sqrt_raised_cos, impulses, 'same');
        t = linspace(0, duration*Tb, duration*Tb*1001);
        %draw eye diagram by taking one/two pulse each iteration and imposing it on the plot
        for i = 1 : duration*Tb*1001 : length(result)
            plot(t, result(1, i : i + duration*Tb*1001 - 1))
            hold on
        end
        grid on; xlim([-0.1 duration*Tb + 0.1]);
        title(sprintf('Eye Diagram of %d level Sqrt Raised Cos PAM with duaration %dTs', pam_level, duration))
        xlabel('time s')
        ylabel('Amplitude V')
end

%% part 4
clear; clc; close;

%below we ask the user for all the parameters needed before we proceed
fprintf('Please choose the pulse shape:\n');
fprintf('1. NRZ\n2. Ideal Nyquist Pulse\n3. Raised-Cosine\n4. Square Root Raised-Cosine\n');
pulse_type = input('Enter the number of the chosen type: ');
pam_level = input('Enter numebr of PAM levels(2 or 8): ');
duration = input('Enter 1 for eye digram of duration Ts or 2 for duration 2Ts: ');
signr = input('Enter Signal to Noise Ratio: ');
%generate 300 random bits uniformly distributed(equiprobable bits)
no_bits = 300; %number of bits to generate
bits = randi([0, 1], 1, no_bits);
Tb = 1; %each pulse is 1 sec
fs = 1000; %sampling freq used to plot pulses

switch pulse_type %decide which pulse type to use based on the user's choice
    case 1 %polar
        encoded = PolarPAM(bits, pam_level);
        %repeat each value in the encoded array Ts*fs times to make it a pulse
        encoded_pulses = repelem(encoded, Tb*fs);
        noisy_encoded_pulses = awgn(encoded_pulses, signr);
        %define the time axis for the desired time(either Ts or 2Ts)
        t = linspace(0, duration*Tb, duration*Tb*fs);
        %draw eye diagram by taking one/two pulse each iteration and imposing it on the plot
        for i = 1 : duration*Tb*fs : length(encoded_pulses)
            noisy_encoded_pulses(1, i) = 0;
            noisy_encoded_pulses(1, i + duration*Tb*fs - 1) = 0;
            plot(t, noisy_encoded_pulses(1, i : i + duration*Tb*fs - 1))
            hold on
        end
        grid on; xlim([-0.1 duration*Tb + 0.1]);
        title(sprintf('Eye Diagram of %d level Polar PAM with duaration %dTs snr = %d', pam_level, duration, signr))
        xlabel('time s')
        ylabel('Amplitude V')
    case 2 %Ideal nyquist
        %define the time axis on which we want to generate the sinc signal
        t_sinc = linspace(-5, 5, Tb*1001*10);
        %generate the sinc signal using the time axis defined above
        raised_cos = sinc(t_sinc);
        %apply polar pam to the input bits to transform the input into correct levels
        input = PolarPAM(bits, pam_level);
        %repeat each value in the encoded array Tb*1001 times to make it a pulse of same width as sinc
        input_pulses = repelem(input, Tb*1001);
        %we want to turn the pulses into just an impulse in the middle of the pulse
        %generate array of zeros same length as the input_pulses
        temp = zeros(1, length(input_pulses));
        %only put 1 in the middle of each pulse
        temp(501:1001:end) = 1;
        %finally to get the impulses multiply element by element in temp and input_pulses
        impulses = temp.*input_pulses;
        %convolve sinc signal and input impulses together to obtain pam modulation
        result = conv(raised_cos, impulses, 'same');
        noisy_result = awgn(result, signr);
        t = linspace(0, duration*Tb, duration*Tb*1001);
        %draw eye diagram by taking one/two pulse each iteration and imposing it on the plot
        for i = 1 : duration*Tb*1001 : length(noisy_result)
            plot(t, noisy_result(1, i : i + duration*Tb*1001 - 1))
            hold on
        end
        grid on; xlim([-0.1 duration*Tb + 0.1]);
        title(sprintf('Eye Diagram of %d level Ideal Nyquist PAM with duaration %dTs snr = %d', pam_level, duration, signr))
        xlabel('time s')
        ylabel('Amplitude V')
    case 3 %raised cos
        %define the time axis on which we want to generate the sinc signal
        t_sinc = linspace(-5, 5, Tb*1001*10);
        %define the roll off factor
        alpha = 1;
        %generate the raised cos signal using the time axis defined above
        raised_cos = sinc(t_sinc).*cos(2*pi*alpha*t_sinc)./(1-16*(alpha^2)*(t_sinc.^2));
        %apply polar pam to the input bits to transform the input into correct levels
        input = PolarPAM(bits, pam_level);
        %repeat each value in the encoded array Tb*1001 times to make it a pulse of same width as sinc
        input_pulses = repelem(input, Tb*1001);
        %we want to turn the pulses into just an impulse in the middle of the pulse
        %generate array of zeros same length as the input_pulses
        temp = zeros(1, length(input_pulses));
        %only put 1 in the middle of each pulse
        temp(501:1001:end) = 1;
        %finally to get the impulses multiply element by element in temp and input_pulses
        impulses = temp.*input_pulses;
        %convolve sinc signal and input impulses together to obtain pam modulation
        result = conv(raised_cos, impulses, 'same');
        noisy_result = awgn(result, signr);
        t = linspace(0, duration*Tb, duration*Tb*1001);
        %draw eye diagram by taking one/two pulse each iteration and imposing it on the plot
        for i = 1 : duration*Tb*1001 : length(noisy_result)
            plot(t, noisy_result(1, i : i + duration*Tb*1001 - 1))
            hold on
        end
        grid on; xlim([-0.1 duration*Tb + 0.1]);
        title(sprintf('Eye Diagram of %d level Raised Cos PAM with duaration %dTs snr=%d', pam_level, duration, signr))
        xlabel('time s')
        ylabel('Amplitude V')
    case 4 %sqrt raised cos
        %define the time axis on which we want to generate the sinc signal
        t_sinc = linspace(-5, 5, Tb*1001*10);
        %define the roll off factor
        alpha = 1; Tc = 0.2604167;
        %generate the raised cos signal using the time axis defined above
        num = cos(pi*t_sinc*(1+alpha)/Tc) + (Tc./(4*alpha*t_sinc)).*sin(pi*t_sinc*(1-alpha)/Tc);
        den = 1 - (4*alpha*t_sinc/Tc).^2;
        sqrt_raised_cos = (4*alpha/(pi*sqrt(Tc)))*num./den;
        %apply polar pam to the input bits to transform the input into correct levels
        input = PolarPAM(bits, pam_level);
        %repeat each value in the encoded array Tb*1001 times to make it a pulse of same width as sinc
        input_pulses = repelem(input, Tb*1001);
        %we want to turn the pulses into just an impulse in the middle of the pulse
        %generate array of zeros same length as the input_pulses
        temp = zeros(1, length(input_pulses));
        %only put 1 in the middle of each pulse
        temp(501:1001:end) = 1;
        %finally to get the impulses multiply element by element in temp and input_pulses
        impulses = temp.*input_pulses;
        %convolve sinc signal and input impulses together to obtain pam modulation
        result = conv(sqrt_raised_cos, impulses, 'same');
        noisy_result = awgn(result, signr);
        t = linspace(0, duration*Tb, duration*Tb*1001);
        %draw eye diagram by taking one/two pulse each iteration and imposing it on the plot
        for i = 1 : duration*Tb*1001 : length(noisy_result)
            plot(t, noisy_result(1, i : i + duration*Tb*1001 - 1))
            hold on
        end
        grid on; xlim([-0.1 duration*Tb + 0.1]);
        title(sprintf('Eye Diagram of %d level Sqrt Raised Cos PAM with duaration %dTs snr=%d', pam_level, duration, signr))
        xlabel('time s')
        ylabel('Amplitude V')
end

%%
function encoded = PolarPAM(bits, pam_level)
if pam_level == 2
    %in pam2 encoded array has the same size as original array
    encoded = ones(size(bits)); %create an array filled with 1s same size as original array
    encoded(bits == 0) = -1; %only set indices where the bit = 0 to the level -1
else %pam level == 8
    %in pam2 encoded array has the (1/3) size as original array as log_2(8) = 3
    encoded = zeros(1, length(bits)/3);
    encoded_index = 1; %will be used as the index of the encoded array inside the loop
    for i = 1 : 3 : length(bits) %each iteration takes three consecutive bits to encode together
        bits_to_encode = bits(1, i : i+2); %extract the bits to be encoded
        num = bin2dec(num2str(bits_to_encode)); %convert the bits to decimal
        encoded(1, encoded_index) = 2*num-7; %the formula 2*num-7 finds the correct level of each num
        encoded_index = encoded_index + 1;
    end
end
end




